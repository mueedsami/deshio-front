'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { Search, Trash2, X, Layers, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import BatchForm from '@/components/BatchForm';
import BatchCard from '@/components/BatchCard';
import GroupedBatchCard, { buildSkuGroups, BatchSkuGroup } from '@/components/GroupedBatchCard';
import batchService, { Batch, CreateBatchData, UpdateBatchData } from '@/services/batchService';
import productService, { ProductSearchHit } from '@/services/productService';
import storeService, { Store } from '@/services/storeService';

interface Product {
  id: number;
  name: string;
}

interface QueuedBatch {
  tempId: string;
  product_id: number;
  product_name: string;
  store_id: number;
  store_name?: string;
  quantity: number;
  cost_price: number;
  sell_price: number;
}

export default function BatchPage() {
  const router = useRouter();

  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const [stores, setStores] = useState<Store[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);

  const [batchSearchQuery, setBatchSearchQuery] = useState('');

  // ✅ Flat search mode: either select a product (recommended) or search by batch number
  const [flatSearchMode, setFlatSearchMode] = useState<'product' | 'batch'>('product');
  const [flatProductFilter, setFlatProductFilter] = useState<ProductSearchHit | null>(null);
  const [productHits, setProductHits] = useState<ProductSearchHit[]>([]);
  const [productHitsOpen, setProductHitsOpen] = useState(false);
  const [productHitsLoading, setProductHitsLoading] = useState(false);


  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [selectedProductName, setSelectedProductName] = useState<string>('');
  const [selectedStoreId, setSelectedStoreId] = useState<number | null>(null);

  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // ✅ Bulk mode states (frontend only)
  const [bulkMode, setBulkMode] = useState(false);
  const [queuedBatches, setQueuedBatches] = useState<QueuedBatch[]>([]);
  const [bulkProgress, setBulkProgress] = useState<{ done: number; total: number } | null>(null);

  // ✅ View mode: grouped by SKU (easy for variations) vs flat batches
  // Default to flat to avoid loading ALL batches on initial page load.
  const [viewMode, setViewMode] = useState<'grouped' | 'flat'>('flat');

  // ✅ Pagination + server-side search for flat view
  const [flatPage, setFlatPage] = useState<number>(1);
  const [flatPerPage, setFlatPerPage] = useState<number>(50);
  const [flatPagination, setFlatPagination] = useState<{
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  }>({ current_page: 1, last_page: 1, per_page: 50, total: 0, from: 0, to: 0 });

  // ✅ Client-side pagination for grouped view (after we fetch all matching batches)
  const [groupPage, setGroupPage] = useState<number>(1);
  const [groupsPerPage, setGroupsPerPage] = useState<number>(12);

  // Read URL parameters when redirected back from product selection
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const pid = params.get('productId');
      const pname = params.get('productName');

      if (pid) setSelectedProductId(Number(pid));
      if (pname) setSelectedProductName(decodeURIComponent(pname));
    }
  }, []);

  useEffect(() => {
    loadInitialData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredBatches = useMemo(() => {
    // Flat view uses backend pagination + backend search, so don't re-filter client-side.
    if (viewMode === 'flat') return batches;

    const q = batchSearchQuery.trim().toLowerCase();
    if (!q) return batches;
    return batches.filter((b) => {
      const productName = String(b.product?.name || '').toLowerCase();
      const productSku = String((b as any).product?.sku || '').toLowerCase();
      const batchNo = String(b.batch_number || '').toLowerCase();
      return productName.includes(q) || productSku.includes(q) || batchNo.includes(q);
    });
  }, [batches, batchSearchQuery, viewMode]);

  const skuGroups: BatchSkuGroup[] = useMemo(() => {
    // Group from the filtered list so search applies naturally.
    return buildSkuGroups(filteredBatches);
  }, [filteredBatches]);

  const groupLastPage = useMemo(() => {
    return Math.max(1, Math.ceil((skuGroups.length || 0) / Math.max(1, groupsPerPage)));
  }, [skuGroups.length, groupsPerPage]);

  const pagedSkuGroups = useMemo(() => {
    const start = (Math.max(1, groupPage) - 1) * Math.max(1, groupsPerPage);
    return skuGroups.slice(start, start + Math.max(1, groupsPerPage));
  }, [skuGroups, groupPage, groupsPerPage]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      setLoadingMessage('Loading stores & batches...');

      // Load stores
      const storesResponse = await storeService.getStores({ is_active: true });
      const storesData = storesResponse.data?.data || storesResponse.data || [];
      setStores(storesData);

      // Set first store as default if none selected
      if (storesData.length > 0 && !selectedStoreId) {
        setSelectedStoreId(storesData[0].id);
      }
    } catch (err) {
      console.error('Error loading data:', err);
      showToast('Failed to load data', 'error');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // ---------------------------
  // ✅ List loaders (Flat: paginated, Grouped: fetch all then client paginate groups)
  // ---------------------------
  const loadFlatBatches = async (args?: { page?: number; per_page?: number }) => {
    const page = Math.max(1, Number(args?.page ?? flatPage) || 1);
    const per_page = Math.max(1, Math.min(100, Number(args?.per_page ?? flatPerPage) || 50));
    try {
      setLoading(true);
      setLoadingMessage('Loading batches...');

      const search = flatSearchMode === 'batch' && batchSearchQuery.trim() ? batchSearchQuery.trim() : undefined;
      const product_id = flatSearchMode === 'product' && flatProductFilter?.id ? flatProductFilter.id : undefined;

      const resp = await batchService.getBatches({
        sort_by: 'created_at',
        sort_order: 'desc',
        page,
        per_page,
        ...(product_id ? { product_id } : {}),
        ...(search ? { search } : {}),
      });

      const items = resp?.data?.data ?? [];
      setBatches(Array.isArray(items) ? items : []);
      setFlatPagination({
        current_page: Number(resp?.data?.current_page || page),
        last_page: Number(resp?.data?.last_page || 1),
        per_page: Number(resp?.data?.per_page || per_page),
        total: Number(resp?.data?.total || 0),
        from: Number(resp?.data?.from || 0),
        to: Number(resp?.data?.to || 0),
      });
    } catch (err) {
      console.error('Error loading flat batches:', err);
      showToast('Failed to load batches', 'error');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  const loadGroupedBatches = async () => {
    try {
      setLoading(true);
      // ⚠️ Do NOT fetch all batches here (it can be thousands).
      // Grouped view will start with a single page (100 max) and can be expanded later if needed.
      setLoadingMessage('Loading batches for grouped view...');

      const resp = await batchService.getBatches({
        sort_by: 'created_at',
        sort_order: 'desc',
        page: 1,
        per_page: 100,
      });
      const items = resp?.data?.data ?? [];
      setBatches(Array.isArray(items) ? items : []);
    } catch (err) {
      console.error('Error loading grouped batches:', err);
      showToast('Failed to load batches', 'error');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  const flatQueryKey = useMemo(() => {
    // In product mode, we only apply search after user selects a product.
    if (flatSearchMode === 'product') {
      return flatProductFilter?.id ? `product:${flatProductFilter.id}` : 'product:none';
    }
    // Batch mode applies backend "search".
    return `batch:${batchSearchQuery.trim()}`;
  }, [flatSearchMode, flatProductFilter?.id, batchSearchQuery]);

  // Product suggestions for flat view (so you can filter batches by product without loading everything)
  useEffect(() => {
    if (viewMode !== 'flat' || flatSearchMode !== 'product') {
      setProductHits([]);
      setProductHitsOpen(false);
      setProductHitsLoading(false);
      return;
    }

    // Once a product is selected, no need to keep suggestions open.
    if (flatProductFilter?.id) {
      setProductHits([]);
      setProductHitsOpen(false);
      setProductHitsLoading(false);
      return;
    }

    const q = batchSearchQuery.trim();
    if (q.length < 2) {
      setProductHits([]);
      setProductHitsLoading(false);
      return;
    }

    const t = setTimeout(async () => {
      try {
        setProductHitsLoading(true);
        const hits = await productService.quickSearch(q, 12);
        setProductHits(Array.isArray(hits) ? hits : []);
      } finally {
        setProductHitsLoading(false);
      }
    }, 250);

    return () => clearTimeout(t);
  }, [viewMode, flatSearchMode, batchSearchQuery, flatProductFilter?.id]);

  // Reload list when view / paging / applied filters change
  useEffect(() => {
    const t = setTimeout(() => {
      if (viewMode === 'flat') {
        loadFlatBatches({ page: flatPage, per_page: flatPerPage });
      } else {
        loadGroupedBatches();
      }
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewMode, flatPage, flatPerPage, flatQueryKey]);

  // Reset paging when search / view changes
  useEffect(() => {
    setFlatPage(1);
    setGroupPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [batchSearchQuery, viewMode]);

  const openProductListForSelection = () => {
    router.push('/product/list?selectMode=true&redirect=/product/batch');
  };

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const handleClear = () => {
    setSelectedProductId(null);
    setSelectedProductName('');
  };

  const selectedProduct = selectedProductId ? { id: selectedProductId, name: selectedProductName } : undefined;
  const selectedStore = selectedStoreId ? stores.find((s) => s.id === selectedStoreId) : undefined;

  // ---------------------------
  // ✅ SINGLE create (existing)
  // ---------------------------
  const handleAddBatch = async (formData: { costPrice: string; sellingPrice: string; quantity: string }) => {
    const { costPrice, sellingPrice, quantity } = formData;

    if (!selectedProductId || !selectedStoreId || !costPrice || !sellingPrice || !quantity) {
      showToast('Please fill all required fields', 'error');
      return;
    }

    const costPriceNum = parseFloat(costPrice);
    const sellingPriceNum = parseFloat(sellingPrice);
    const quantityNum = parseInt(quantity);

    // Validate positive numbers
    if (
      isNaN(costPriceNum) ||
      isNaN(sellingPriceNum) ||
      isNaN(quantityNum) ||
      costPriceNum <= 0 ||
      sellingPriceNum <= 0 ||
      quantityNum <= 0
    ) {
      showToast('Please enter valid positive numbers', 'error');
      return;
    }

    try {
      setLoading(true);
      setLoadingMessage('Creating batch and generating barcodes...');

      const batchData: CreateBatchData = {
        product_id: selectedProductId,
        store_id: selectedStoreId,
        quantity: quantityNum,
        cost_price: costPriceNum,
        sell_price: sellingPriceNum,
        // ✅ Generate barcodes during batch creation
        generate_barcodes: true,
        barcode_type: 'CODE128',
        // ✅ Generate individual barcodes for each unit (if quantity <= 100)
        individual_barcodes: quantityNum <= 100,
      };

      const response = await batchService.createBatch(batchData);

      // Reload list to include newly created batch
      if (viewMode === 'flat') {
        setFlatPage(1);
        await loadFlatBatches({ page: 1, per_page: flatPerPage });
      } else {
        await loadGroupedBatches();
      }

      showToast(
        `Batch created successfully! ${response.data?.barcodes_generated ?? ''} barcode(s) generated.`,
        'success'
      );

      // Clear selection
      handleClear();
    } catch (err: any) {
      console.error('Failed to create batch:', err);
      showToast(err.response?.data?.message || 'Failed to create batch', 'error');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // ---------------------------
  // ✅ BULK: add to queue
  // ---------------------------
  const handleQueueAdd = async (formData: { costPrice: string; sellingPrice: string; quantity: string }) => {
    const { costPrice, sellingPrice, quantity } = formData;

    if (!selectedProductId || !selectedStoreId || !costPrice || !sellingPrice || !quantity) {
      showToast('Please fill all required fields', 'error');
      return;
    }

    const costPriceNum = parseFloat(costPrice);
    const sellingPriceNum = parseFloat(sellingPrice);
    const quantityNum = parseInt(quantity);

    if (
      isNaN(costPriceNum) ||
      isNaN(sellingPriceNum) ||
      isNaN(quantityNum) ||
      costPriceNum <= 0 ||
      sellingPriceNum <= 0 ||
      quantityNum <= 0
    ) {
      showToast('Please enter valid positive numbers', 'error');
      return;
    }

    // prevent duplicate same product+store in queue (optional safety)
    const exists = queuedBatches.some(
      (q) => q.product_id === selectedProductId && q.store_id === selectedStoreId
    );
    if (exists) {
      showToast('This product is already in the queue for the selected store', 'error');
      return;
    }

    const store = stores.find((s) => s.id === selectedStoreId);

    const item: QueuedBatch = {
      tempId: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      product_id: selectedProductId,
      product_name: selectedProductName || `Product #${selectedProductId}`,
      store_id: selectedStoreId,
      store_name: (store as any)?.name,
      quantity: quantityNum,
      cost_price: costPriceNum,
      sell_price: sellingPriceNum,
    };

    setQueuedBatches((prev) => [item, ...prev]);

    showToast(`Added to queue (${queuedBatches.length + 1})`, 'success');

    // Clear selected product so user can quickly pick next one
    handleClear();
  };

  const removeQueuedItem = (tempId: string) => {
    setQueuedBatches((prev) => prev.filter((x) => x.tempId !== tempId));
  };

  const clearQueue = () => {
    setQueuedBatches([]);
    setBulkProgress(null);
  };

  const createQueuedBatches = async () => {
    if (queuedBatches.length === 0) {
      showToast('Queue is empty', 'error');
      return;
    }

    setLoading(true);
    setLoadingMessage(`Creating ${queuedBatches.length} batch(es) and generating barcodes...`);
    setBulkProgress({ done: 0, total: queuedBatches.length });

    let successCount = 0;
    const failed: QueuedBatch[] = [];

    try {
      // ✅ sequential is safer (rate limit / server load)
      for (let i = 0; i < queuedBatches.length; i++) {
        const q = queuedBatches[i];

        const payload: CreateBatchData = {
          product_id: q.product_id,
          store_id: q.store_id,
          quantity: q.quantity,
          cost_price: q.cost_price,
          sell_price: q.sell_price,
          generate_barcodes: true,
          barcode_type: 'CODE128',
          individual_barcodes: q.quantity <= 100,
        };

        try {
          await batchService.createBatch(payload);
          successCount += 1;
        } catch (err) {
          console.error('Bulk create failed for:', q, err);
          failed.push(q);
        } finally {
          setBulkProgress({ done: i + 1, total: queuedBatches.length });
        }
      }

      // Reload list to include newly created batches
      if (viewMode === 'flat') {
        setFlatPage(1);
        await loadFlatBatches({ page: 1, per_page: flatPerPage });
      } else {
        await loadGroupedBatches();
      }

      // Keep only failed rows so user can retry quickly
      setQueuedBatches(failed);

      if (failed.length === 0) {
        showToast(`Created ${successCount} batch(es) successfully`, 'success');
        setBulkProgress(null);
      } else {
        showToast(`Created ${successCount}, failed ${failed.length} (failed kept in queue)`, 'error');
      }
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  // ---------------------------
  // Edit/Delete (existing)
  // ---------------------------
  const handleEditBatch = async (batchId: number, data: UpdateBatchData) => {
    try {
      const response = await batchService.updateBatch(batchId, data);

      setBatches((prev) => prev.map((b) => (b.id === batchId ? response.data : b)));
      showToast('Batch updated successfully', 'success');
      sessionStorage.setItem('product_list_refresh_needed', '1');
    } catch (err: any) {
      console.error('Failed to update batch:', err);
      const errorMsg = err.response?.data?.message || 'Failed to update batch';
      showToast(errorMsg, 'error');
      throw err;
    }
  };

  const handleDeleteBatch = async (batchId: number) => {
    try {
      await batchService.deleteBatch(batchId);
      // Keep UI snappy, then refresh counts/pagination
      setBatches((prev) => prev.filter((b) => b.id !== batchId));
      showToast('Batch deactivated successfully', 'success');

      if (viewMode === 'flat') {
        // Reload current page (or previous if this page becomes empty)
        const nextPage = Math.min(flatPagination.last_page || flatPage, flatPage);
        await loadFlatBatches({ page: nextPage, per_page: flatPerPage });
      } else {
        await loadGroupedBatches();
      }
    } catch (err: any) {
      console.error('Failed to delete batch:', err);
      const errorMsg = err.response?.data?.message || 'Failed to delete batch';
      showToast(errorMsg, 'error');
    }
  };

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <div className="flex-1 flex flex-col overflow-hidden">
          <Header darkMode={darkMode} setDarkMode={setDarkMode} toggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

          <main className="flex-1 overflow-y-auto p-6">
            <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Batches</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {bulkMode
                    ? 'Bulk mode: queue multiple products, then create all at once'
                    : 'Create a batch and generate barcodes automatically'}
                </p>
              </div>

              {/* ✅ Mode Toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setBulkMode(false)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium border transition ${
                    !bulkMode
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  Single
                </button>
                <button
                  onClick={() => setBulkMode(true)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium border transition ${
                    bulkMode
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  Bulk
                </button>
              </div>
            </div>

            <BatchForm
              selectedProduct={selectedProduct}
              selectedStore={selectedStore}
              stores={stores}
              onProductClick={openProductListForSelection}
              onStoreChange={setSelectedStoreId}
              onAddBatch={bulkMode ? handleQueueAdd : handleAddBatch}
              onClear={handleClear}
              loading={loading}
            />

            {/* ✅ Loading indicator with progress */}
            {loading && (
              <div className="mb-4 flex items-center justify-center py-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mr-3"></div>
                <span className="text-blue-600 dark:text-blue-400">
                  {loadingMessage || 'Working...'}
                  {bulkProgress ? ` (${bulkProgress.done}/${bulkProgress.total})` : ''}
                </span>
              </div>
            )}

            {/* ✅ Bulk Queue Panel */}
            {bulkMode && (
              <div className="mb-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Queue</h3>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {queuedBatches.length} item{queuedBatches.length !== 1 ? 's' : ''}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={clearQueue}
                      disabled={queuedBatches.length === 0 || loading}
                      className="px-3 py-2 rounded-lg text-sm font-medium border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50"
                    >
                      Clear
                    </button>

                    <button
                      onClick={createQueuedBatches}
                      disabled={queuedBatches.length === 0 || loading}
                      className="px-4 py-2 rounded-lg text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
                    >
                      Create All ({queuedBatches.length})
                    </button>
                  </div>
                </div>

                {queuedBatches.length === 0 ? (
                  <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                    Add products one by one (form → select product → fill qty/prices → submit) to build the queue.
                  </div>
                ) : (
                  <div className="mt-4 space-y-2">
                    {queuedBatches.map((q) => (
                      <div
                        key={q.tempId}
                        className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 p-3 rounded-lg border border-gray-200 dark:border-gray-700"
                      >
                        <div className="min-w-0">
                          <div className="font-semibold text-gray-900 dark:text-white truncate">
                            {q.product_name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            Store: {q.store_name || q.store_id} • Qty: {q.quantity} • Cost: {q.cost_price} • Sell: {q.sell_price}
                          </div>
                        </div>

                        <button
                          onClick={() => removeQueuedItem(q.tempId)}
                          disabled={loading}
                          className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium border border-red-200 dark:border-red-800 text-red-600 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 disabled:opacity-50"
                        >
                          <Trash2 className="w-4 h-4" />
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Small hint */}
                <div className="mt-4 flex items-start gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <AlertTriangle className="w-4 h-4 mt-0.5" />
                  <span>
                    In bulk create, if any item fails, it will stay in the queue so you can retry quickly.
                  </span>
                </div>
              </div>
            )}

            <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="flex items-end gap-3">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {viewMode === 'grouped' ? 'Products (Grouped by SKU)' : 'Recent Batches'}
                </h2>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {viewMode === 'grouped' ? (
                    <>
                      {skuGroups.length} product group{skuGroups.length !== 1 ? 's' : ''}
                      {skuGroups.length > groupsPerPage ? (
                        <span className="ml-2 text-xs text-gray-400 dark:text-gray-500">
                          (showing {(Math.max(1, groupPage) - 1) * groupsPerPage + 1}–{Math.min(groupPage * groupsPerPage, skuGroups.length)} of {skuGroups.length})
                        </span>
                      ) : null}
                    </>
                  ) : (
                    <>
                      {flatPagination.total} batch{flatPagination.total !== 1 ? 'es' : ''}
                      {flatPagination.total ? (
                        <span className="ml-2 text-xs text-gray-400 dark:text-gray-500">
                          (showing {flatPagination.from}–{flatPagination.to})
                        </span>
                      ) : null}
                    </>
                  )}
                  {viewMode === 'grouped'
                    ? (batchSearchQuery.trim() ? <span className="ml-1">(searched)</span> : null)
                    : (flatSearchMode === 'batch'
                        ? (batchSearchQuery.trim() ? <span className="ml-1">(searched)</span> : null)
                        : (flatProductFilter ? <span className="ml-1">(filtered)</span> : null)
                      )}
                </span>
              </div>

              {/* View toggle */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setViewMode('grouped')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium border transition ${
                    viewMode === 'grouped'
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  Grouped
                </button>
                <button
                  onClick={() => setViewMode('flat')}
                  className={`px-3 py-2 rounded-lg text-sm font-medium border transition ${
                    viewMode === 'flat'
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  Flat
                </button>

                {/* Per-page controls */}
                {viewMode === 'flat' ? (
                  <div className="flex items-center gap-2 ml-1">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Per page</span>
                    <select
                      value={flatPerPage}
                      onChange={(e) => setFlatPerPage(Number(e.target.value) || 50)}
                      className="px-2 py-2 rounded-lg text-sm border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    >
                      <option value={20}>20</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </select>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 ml-1">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Groups/page</span>
                    <select
                      value={groupsPerPage}
                      onChange={(e) => setGroupsPerPage(Number(e.target.value) || 12)}
                      className="px-2 py-2 rounded-lg text-sm border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    >
                      <option value={6}>6</option>
                      <option value={12}>12</option>
                      <option value={24}>24</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Search */}
              <div className="w-full md:w-[520px]">
                {viewMode === 'flat' ? (
                  <div className="mb-2 flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-gray-500 dark:text-gray-400">Search by</span>
                    <select
                      value={flatSearchMode}
                      onChange={(e) => {
                        const mode = (e.target.value as any) as 'product' | 'batch';
                        setFlatSearchMode(mode);
                        setFlatPage(1);
                        setProductHits([]);
                        setProductHitsOpen(false);
                        if (mode === 'batch') setFlatProductFilter(null);
                      }}
                      className="px-2 py-2 rounded-lg text-sm border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    >
                      <option value="product">Product (name/SKU)</option>
                      <option value="batch">Batch number</option>
                    </select>

                    {flatSearchMode === 'product' && flatProductFilter ? (
                      <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300">
                        {flatProductFilter.name}
                        <button
                          type="button"
                          onClick={() => {
                            setFlatProductFilter(null);
                            setBatchSearchQuery('');
                            setProductHits([]);
                            setProductHitsOpen(false);
                            setFlatPage(1);
                          }}
                          className="hover:opacity-80"
                          title="Clear product filter"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </span>
                    ) : null}
                  </div>
                ) : null}

                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={batchSearchQuery}
                    onChange={(e) => {
                      const v = e.target.value;
                      setBatchSearchQuery(v);
                      if (viewMode === 'flat' && flatSearchMode === 'product') {
                        // Typing a new keyword should clear existing product selection.
                        if (flatProductFilter && v.trim() !== flatProductFilter.name) {
                          setFlatProductFilter(null);
                        }
                        setProductHitsOpen(true);
                      }
                    }}
                    onFocus={() => {
                      if (viewMode === 'flat' && flatSearchMode === 'product') setProductHitsOpen(true);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && viewMode === 'flat' && flatSearchMode === 'product' && !flatProductFilter) {
                        // Convenience: Enter selects the first suggestion.
                        const first = productHits?.[0];
                        if (first?.id) {
                          setFlatProductFilter(first);
                          setBatchSearchQuery(first.name || '');
                          setProductHitsOpen(false);
                          setFlatPage(1);
                        }
                      }
                    }}
                    placeholder={
                      viewMode === 'flat'
                        ? flatSearchMode === 'product'
                          ? 'Type product name/SKU, then pick from suggestions…'
                          : 'Type batch number…'
                        : 'Search within loaded list…'
                    }
                    className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />

                  {batchSearchQuery.trim() ? (
                    <button
                      type="button"
                      onClick={() => {
                        setBatchSearchQuery('');
                        setProductHits([]);
                        setProductHitsOpen(false);
                        // Only clear product filter if we were searching by product.
                        if (flatSearchMode === 'product') setFlatProductFilter(null);
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      title="Clear"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  ) : null}

                  {/* Product suggestions dropdown (flat + product mode) */}
                  {viewMode === 'flat' && flatSearchMode === 'product' && !flatProductFilter && productHitsOpen ? (
                    <div className="absolute z-50 mt-2 w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-lg overflow-hidden">
                      {productHitsLoading ? (
                        <div className="p-3 text-sm text-gray-500 dark:text-gray-400">Searching products…</div>
                      ) : productHits.length === 0 ? (
                        <div className="p-3 text-sm text-gray-500 dark:text-gray-400">
                          {batchSearchQuery.trim().length < 2 ? 'Type at least 2 characters to search products.' : 'No matching products found.'}
                        </div>
                      ) : (
                        <div className="max-h-72 overflow-auto">
                          {productHits.map((p) => (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => {
                                setFlatProductFilter(p);
                                setBatchSearchQuery(p.name || '');
                                setProductHitsOpen(false);
                                setFlatPage(1);
                              }}
                              className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700"
                            >
                              <div className="text-sm font-semibold text-gray-900 dark:text-white truncate">{p.name}</div>
                              <div className="text-xs text-gray-500 dark:text-gray-400 truncate">SKU: {p.sku || '—'}</div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>

            <div className={
              viewMode === 'grouped'
                ? 'grid grid-cols-1 lg:grid-cols-2 gap-6'
                : 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }>
              {(viewMode === 'grouped' ? skuGroups.length === 0 : filteredBatches.length === 0) && !loading ? (
                <div className="col-span-full text-center py-12 bg-white dark:bg-gray-800 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700">
                  <svg className="w-16 h-16 mx-auto text-gray-400 dark:text-gray-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                  </svg>
                  <p className="text-gray-500 dark:text-gray-400 font-medium">
                    {batchSearchQuery.trim()
                      ? (viewMode === 'grouped' ? 'No products match your search' : 'No batches match your search')
                      : (viewMode === 'grouped' ? 'No stock entries yet' : 'No batches created yet')}
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                    {batchSearchQuery.trim()
                      ? 'Try a different keyword (product name / SKU / batch number).'
                      : 'Create your first batch to get started'}
                  </p>
                </div>
              ) : viewMode === 'grouped' ? (
                pagedSkuGroups.map((g) => <GroupedBatchCard key={g.sku || String(g.variants?.[0]?.productId || Math.random())} group={g} />)
              ) : (
                filteredBatches.map((batch) => (
                  <BatchCard key={batch.id} batch={batch} onDelete={handleDeleteBatch} onEdit={handleEditBatch} />
                ))
              )}
            </div>

            {/* Pagination controls */}
            {viewMode === 'flat' && flatPagination.last_page > 1 ? (
              <div className="mt-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Page <span className="font-semibold text-gray-900 dark:text-white">{flatPagination.current_page}</span> /{' '}
                  <span className="font-semibold text-gray-900 dark:text-white">{flatPagination.last_page}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setFlatPage((p) => Math.max(1, p - 1))}
                    disabled={flatPagination.current_page <= 1 || loading}
                    className="px-3 py-2 rounded-lg text-sm font-semibold border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white disabled:opacity-50"
                  >
                    Prev
                  </button>
                  <button
                    type="button"
                    onClick={() => setFlatPage((p) => Math.min(flatPagination.last_page || p + 1, p + 1))}
                    disabled={flatPagination.current_page >= flatPagination.last_page || loading}
                    className="px-3 py-2 rounded-lg text-sm font-semibold border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white disabled:opacity-50"
                  >
                    Next
                  </button>
                </div>
              </div>
            ) : null}

            {viewMode === 'grouped' && skuGroups.length > groupsPerPage ? (
              <div className="mt-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Page <span className="font-semibold text-gray-900 dark:text-white">{Math.min(groupLastPage, Math.max(1, groupPage))}</span> /{' '}
                  <span className="font-semibold text-gray-900 dark:text-white">{groupLastPage}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setGroupPage((p) => Math.max(1, p - 1))}
                    disabled={groupPage <= 1 || loading}
                    className="px-3 py-2 rounded-lg text-sm font-semibold border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white disabled:opacity-50"
                  >
                    Prev
                  </button>
                  <button
                    type="button"
                    onClick={() => setGroupPage((p) => Math.min(groupLastPage, p + 1))}
                    disabled={groupPage >= groupLastPage || loading}
                    className="px-3 py-2 rounded-lg text-sm font-semibold border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white disabled:opacity-50"
                  >
                    Next
                  </button>
                </div>
              </div>
            ) : null}
          </main>
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 px-6 py-4 rounded-lg shadow-xl text-white transform transition-all duration-300 z-50 ${
            toast.type === 'success' ? 'bg-green-500' : 'bg-red-500'
          } animate-slideIn`}
        >
          <div className="flex items-center gap-3">
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-6 h-6" />
            ) : (
              <X className="w-6 h-6" />
            )}
            <span className="font-medium">{toast.message}</span>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
