export const CLIENT_NAME = "Deshio" as const;
export const CLIENT_NAME_CAP = "DESHIO" as const;
export const CLIENT_WEBSITE = "deshio.com.bd" as const;

// Public contact channels (e-commerce)
export const CLIENT_EMAIL = "contact@deshio.com.bd" as const;
export const CLIENT_PHONE = "+8809611-678943" as const;
export const CLIENT_MOBILE = "+8801711-585400" as const;
export const CLIENT_ADDRESS =
  "House 4, Road 1, Dhaka Housing, Adabor, Mohammadpur, Dhaka-1207" as const;
export const CLIENT_SUPPORT_HOURS = "Sat – Thu, 10:00 AM – 7:00 PM" as const;
export const CLIENT_FACEBOOK = "https://www.facebook.com/desshio" as const;