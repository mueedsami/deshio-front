// lib/qz-tray.ts
// QZ Tray integration utilities.
//
// This module keeps the same exported API used across the app.
// If QZ Tray isn't available/running, receipt printing falls back to the
// existing browser receipt preview modal (Print → Save as PDF) so the user
// can still proceed.

import { openReceiptModal, openBulkReceiptModal, type ReceiptTemplate } from '@/lib/receiptModal';

type QZStatus = { connected: boolean; version?: string; error?: string };

const QZ_SCRIPT_URL = 'https://cdn.jsdelivr.net/npm/qz-tray@2.2.4/qz-tray.js';

let qzScriptPromise: Promise<void> | null = null;
let qzConnectPromise: Promise<boolean> | null = null;

function getQz(): any | null {
  if (typeof window === 'undefined') return null;
  return (window as any).qz || null;
}

function loadScriptOnce(src: string): Promise<void> {
  if (qzScriptPromise) return qzScriptPromise;
  qzScriptPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined') return resolve();

    // Already loaded?
    if ((window as any).qz) return resolve();

    const existing = document.querySelector(`script[data-qz-tray="true"]`) as HTMLScriptElement | null;
    if (existing && (window as any).qz) return resolve();

    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.defer = true;
    s.dataset.qzTray = 'true';
    s.onload = () => resolve();
    s.onerror = (e) => reject(e);
    document.head.appendChild(s);
  });
  return qzScriptPromise;
}

async function ensureQZLoaded(): Promise<any> {
  const qz = getQz();
  if (qz) return qz;
  await loadScriptOnce(QZ_SCRIPT_URL);
  const after = getQz();
  if (!after) throw new Error('QZ Tray library not loaded');
  return after;
}

async function isWebsocketActive(qz: any): Promise<boolean> {
  const active = qz?.websocket?.isActive?.();
  // qz-tray sometimes returns boolean; some wrappers may return Promise<boolean>
  return typeof (active as any)?.then === 'function' ? await active : !!active;
}

export async function connectQZ(): Promise<boolean> {
  if (qzConnectPromise) return qzConnectPromise;

  qzConnectPromise = (async () => {
    const qz = await ensureQZLoaded();

    // Try to connect only if not already active
    if (!(await isWebsocketActive(qz))) {
      try {
        await qz.websocket.connect();
      } catch (e: any) {
        // Many deployments enable "Allow unsigned requests" in QZ Tray.
        // If the user has signature enforcement enabled, connection will fail.
        // We surface the message so they can fix QZ settings for tomorrow's delivery.
        throw new Error(e?.message || 'Unable to establish connection to QZ Tray');
      }
    }

    return await isWebsocketActive(qz);
  })();

  try {
    return await qzConnectPromise;
  } finally {
    qzConnectPromise = null;
  }
}

export async function disconnectQZ(): Promise<void> {
  try {
    const qz = getQz();
    if (!qz) return;
    if (await isWebsocketActive(qz)) {
      await qz.websocket.disconnect();
    }
  } catch {
    // ignore
  }
}

export async function getPrinters(): Promise<string[]> {
  const qz = await ensureQZLoaded();
  await connectQZ();
  const printers = await qz.printers.find();
  return Array.isArray(printers) ? printers : [];
}

export async function getDefaultPrinter(): Promise<string | null> {
  const qz = await ensureQZLoaded();
  await connectQZ();

  // Prefer persisted printer, then QZ default, then first available
  const preferred = await getPreferredPrinter();
  if (preferred) return preferred;

  try {
    const p = await qz.printers.getDefault();
    if (p) return p;
  } catch {
    // ignore
  }

  try {
    const list = await qz.printers.find();
    if (Array.isArray(list) && list.length) return list[0];
  } catch {
    // ignore
  }

  return null;
}

export async function getPreferredPrinter(): Promise<string | null> {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('preferredPrinter') || localStorage.getItem('defaultPrinter');
}

export function savePreferredPrinter(printerName: string) {
  if (typeof window === 'undefined') return;
  localStorage.setItem('preferredPrinter', printerName);
}

async function qzPrintHtml(html: string, printerName?: string | null): Promise<boolean> {
  const qz = await ensureQZLoaded();
  await connectQZ();

  const printer = printerName || (await getDefaultPrinter());
  if (!printer) throw new Error('No printer found. Set a default printer and try again.');

  const config = qz.configs.create(printer);
  const data = [{ type: 'html', format: 'plain', data: html }];
  await qz.print(config, data);
  return true;
}

// ---- Barcode label helpers (no JS executed inside QZ print job) ----

function generateBarcodeSvg(code: string): string {
  // Uses JsBarcode loaded globally by QZTrayLoader.
  const JsBarcode = (window as any)?.JsBarcode;
  if (!JsBarcode) throw new Error('JsBarcode not available');

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

  JsBarcode(svg, String(code), {
    format: 'CODE128',
    width: 1.3,
    height: 30,
    displayValue: true,
    fontSize: 9,
    margin: 0,
    marginTop: 1,
    marginBottom: 1,
    textMargin: 1,
  });

  return svg.outerHTML;
}

export async function printBarcodeLabel(
  params: { barcode: string; productName?: string; price?: string | number },
  printerName?: string
): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  const safeName = (params.productName || 'Product').substring(0, 25);
  const priceNum = Number(params.price);
  const showPrice = Number.isFinite(priceNum) && priceNum > 0;
  const priceText = showPrice ? `৳${Number(priceNum).toLocaleString('en-BD')}` : '';

  const barcodeSvg = generateBarcodeSvg(params.barcode);
  const html = `
    <html>
      <head>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          @page { size: 40mm 28mm; margin: 0; }
          body {
            width: 40mm; height: 28mm; margin: 0; padding: 0.5mm 1mm;
            font-family: Arial, sans-serif; display: flex; flex-direction: column;
            justify-content: space-between; align-items: center;
          }
          .barcode-container {
            width: 100%; text-align: center; display:flex; flex-direction:column;
            align-items:center; justify-content:center;
          }
          .product-name {
            font-weight: bold; font-size: 7pt; line-height: 1; margin-bottom: 0.5mm;
            max-width: 38mm; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
          }
          .price { font-size: 9pt; font-weight: bold; color: #000; margin-bottom: 0.5mm; line-height: 1; }
          svg { max-width: 38mm; height: auto; display: block; }
        </style>
      </head>
      <body>
        <div class="barcode-container">
          <div class="product-name">${safeName}</div>
          ${showPrice ? `<div class="price">${priceText}</div>` : ``}
          ${barcodeSvg}
        </div>
      </body>
    </html>
  `;

  return qzPrintHtml(html, printerName);
}

// ---- Receipts ----

export async function printReceipt(
  order: any,
  printerName?: string,
  opts?: { template?: ReceiptTemplate; title?: string }
): Promise<boolean> {
  // Receipts are currently rendered via in-app modal.
  // We keep this behavior (no functionality change), but we still ensure
  // QZ is available so pages can show an accurate status indicator.
  try {
    // Best-effort connect (for status UI). If it fails, still allow modal.
    await connectQZ().catch(() => false);
  } catch {
    // ignore
  }

  try {
    // If you later add a printable HTML template string, you can send it to qzPrintHtml.
    // For now, keep the existing flow.
    openReceiptModal(order, { template: opts?.template, title: opts?.title });
    return true;
  } catch (e) {
    console.error('❌ Failed to open receipt modal:', e);
    return false;
  }
}

export async function printBulkReceipts(
  orders: any[],
  printerName?: string,
  opts?: { template?: ReceiptTemplate; title?: string }
): Promise<{ successCount: number; failCount: number }> {
  try {
    await connectQZ().catch(() => false);
  } catch {
    // ignore
  }

  try {
    openBulkReceiptModal(orders, { template: opts?.template, title: opts?.title });
    return { successCount: 0, failCount: 0 };
  } catch (e) {
    console.error('❌ Failed to open bulk receipt modal:', e);
    return { successCount: 0, failCount: Array.isArray(orders) ? orders.length : 0 };
  }
}

export async function checkQZStatus(): Promise<QZStatus> {
  try {
    const qz = getQz();
    if (!qz) {
      return { connected: false, error: 'QZ Tray library not loaded' };
    }

    // Prefer a live connection so pages can show accurate status.
    // If QZ Tray is running, this is fast; if not, we'll return an error.
    try {
      if (!(await isWebsocketActive(qz))) {
        await connectQZ();
      }
    } catch (e: any) {
      return { connected: false, error: e?.message || 'QZ Tray not connected' };
    }

    const active = await isWebsocketActive(qz);
    if (!active) return { connected: false, error: 'QZ Tray not connected' };

    let version: string | undefined;
    try {
      version = (await qz.api?.getVersion?.()) || qz.version;
    } catch {
      version = qz.version;
    }

    return { connected: true, version };
  } catch (e: any) {
    return { connected: false, error: e?.message || 'QZ status check failed' };
  }
}
