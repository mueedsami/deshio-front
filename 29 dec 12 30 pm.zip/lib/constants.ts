export const CLIENT_NAME = "DESHIO" as const;
export const CLIENT_NAME_CAP = "errum" as const;
// export const CLIENT_WEBSITE = "www.deshio.com" as const;
export const CLIENT_EMAIL = "support@deshio.com" as const;